//
//  QqcJsonResultModel.h
//  QqcRequestFramework
//
//  Created by qiuqinchuan on 15/8/10.
//  Copyright (c) 2015年 Qqc. All rights reserved.
//


#import "QqcJsonResultModel.h"

@implementation QqcJsonResultModel

@end
