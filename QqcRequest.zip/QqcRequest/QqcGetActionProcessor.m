//
//  QqcGetActionProcessor.m
//  QqcRequestFramework
//
//  Created by qiuqinchuan on 16/3/1.
//  Copyright © 2016年 Qqc. All rights reserved.
//

#import "QqcGetActionProcessor.h"

@implementation QqcGetActionProcessor

- (QqcRequestMethod)requestMethod
{
    return QqcRequestMethodGet;
}

@end
