//
//  QqcDataModel.h
//  QqcRequestFramework
//
//  Created by qiuqinchuan on 16/3/2.
//  Copyright © 2016年 Qqc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "QqcBaseModel.h"

@interface QqcDataModel : QqcBaseModel

@end
