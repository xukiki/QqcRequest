//
//  QqcGetActionProcessor.h
//  QqcRequestFramework
//
//  Created by qiuqinchuan on 16/3/1.
//  Copyright © 2016年 Qqc. All rights reserved.
//

#import "QqcBaseActionProcessor.h"

@interface QqcGetActionProcessor : QqcBaseActionProcessor

@end
