//
//  QqcParamPostFile.m
//  QqcRequestFramework
//
//  Created by admin on 16/3/22.
//  Copyright © 2016年 Qqc. All rights reserved.
//

#import "QqcParamPostFile.h"

@implementation QqcParamPostFile

@end
